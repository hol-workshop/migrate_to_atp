--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1 (Ubuntu 13.1-1.pgdg18.04+1)
-- Dumped by pg_dump version 13.1 (Ubuntu 13.1-1.pgdg18.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "ParkingData";
--
-- Name: ParkingData; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "ParkingData" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C.UTF-8';


ALTER DATABASE "ParkingData" OWNER TO postgres;

\connect "ParkingData"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Cities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Cities" (
    "CityID" character varying(3),
    "City" character varying(30),
    "CountryID" character varying(3)
);

ALTER TABLE ONLY public."Cities" REPLICA IDENTITY FULL;


ALTER TABLE public."Cities" OWNER TO postgres;

--
-- Name: Countries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Countries" (
    "CountryID" character varying(3),
    "Country" character varying(40),
    "RegionID" integer
);

ALTER TABLE ONLY public."Countries" REPLICA IDENTITY FULL;


ALTER TABLE public."Countries" OWNER TO postgres;

--
-- Name: ParkingData; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ParkingData" (
    "ParkingDataID" numeric(18,0),
    "ParkingID" character varying(12),
    "CarRegID" character varying(12),
    "InTime" timestamp without time zone,
    "OutTime" timestamp without time zone,
    "ParkingRate" real
);

ALTER TABLE ONLY public."ParkingData" REPLICA IDENTITY FULL;


ALTER TABLE public."ParkingData" OWNER TO postgres;

--
-- Name: Parkings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Parkings" (
    "ParkingID" character varying(12),
    "ParkingName" character varying(30),
    "AvailableSlot" integer,
    "CountryID" character varying(3),
    "CityID" character varying(3),
    "StreetAddress" character varying(40),
    "Longitude" real,
    "Latitude" real
);

ALTER TABLE ONLY public."Parkings" REPLICA IDENTITY FULL;


ALTER TABLE public."Parkings" OWNER TO postgres;

--
-- Name: PaymentData; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PaymentData" (
    "TransactionID" character varying(24),
    "TransactionAmount" real,
    "TransactionMethod" character varying(8),
    "ParkingDataID" numeric(18,0),
    "ParkingID" character varying(12)
);

ALTER TABLE ONLY public."PaymentData" REPLICA IDENTITY FULL;


ALTER TABLE public."PaymentData" OWNER TO postgres;

--
-- Name: SQParkingData; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SQParkingData"
    START WITH 100000000000000000
    INCREMENT BY 1
    MINVALUE 0
    MAXVALUE 999999999999999999
    CACHE 1;


ALTER TABLE public."SQParkingData" OWNER TO postgres;

--
-- Data for Name: Cities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Cities" ("CityID", "City", "CountryID") FROM stdin;
\.
COPY public."Cities" ("CityID", "City", "CountryID") FROM '$$PATH$$/2939.dat';

--
-- Data for Name: Countries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Countries" ("CountryID", "Country", "RegionID") FROM stdin;
\.
COPY public."Countries" ("CountryID", "Country", "RegionID") FROM '$$PATH$$/2940.dat';

--
-- Data for Name: ParkingData; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ParkingData" ("ParkingDataID", "ParkingID", "CarRegID", "InTime", "OutTime", "ParkingRate") FROM stdin;
\.
COPY public."ParkingData" ("ParkingDataID", "ParkingID", "CarRegID", "InTime", "OutTime", "ParkingRate") FROM '$$PATH$$/2942.dat';

--
-- Data for Name: Parkings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Parkings" ("ParkingID", "ParkingName", "AvailableSlot", "CountryID", "CityID", "StreetAddress", "Longitude", "Latitude") FROM stdin;
\.
COPY public."Parkings" ("ParkingID", "ParkingName", "AvailableSlot", "CountryID", "CityID", "StreetAddress", "Longitude", "Latitude") FROM '$$PATH$$/2941.dat';

--
-- Data for Name: PaymentData; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PaymentData" ("TransactionID", "TransactionAmount", "TransactionMethod", "ParkingDataID", "ParkingID") FROM stdin;
\.
COPY public."PaymentData" ("TransactionID", "TransactionAmount", "TransactionMethod", "ParkingDataID", "ParkingID") FROM '$$PATH$$/2944.dat';

--
-- Name: SQParkingData; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SQParkingData"', 100000000000010364, true);


--
-- PostgreSQL database dump complete
--

